import type { Metadata } from "next"
import "./globals.css"
import Navbar from "@/components/Navbar"
import Footer from "@/components/Footer"
import StarField from "@/components/StarField"
import { AuthProvider } from "@/lib/auth-context"

export const metadata: Metadata = {
  metadataBase: new URL("http://localhost:3000"),
  title: "Shift Orbit — Independent Game Studio",
  description: "We craft immersive gaming experiences from the stars. Shift Orbit is an independent game studio.",
  icons: { icon: "/logo.png" },
  openGraph: {
    title: "Shift Orbit",
    description: "Independent Game Studio",
    images: ["/logo.png"],
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="nebula-bg min-h-screen">
        <AuthProvider>
          <StarField />
          <Navbar />
          <main className="relative z-10">
            {children}
          </main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  )
}
